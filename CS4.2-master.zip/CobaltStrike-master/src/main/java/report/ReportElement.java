package report;

public interface ReportElement {
    void publish(StringBuffer stringBuffer);
}
