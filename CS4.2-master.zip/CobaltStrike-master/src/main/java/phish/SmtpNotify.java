package phish;

public interface SmtpNotify {
    void update(String string);
}
