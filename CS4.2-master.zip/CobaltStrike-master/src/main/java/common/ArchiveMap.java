package common;

import java.util.HashMap;
import java.util.Map;

public class ArchiveMap extends HashMap implements Transcript {
    public ArchiveMap(Map map) {
        super(map);
    }
}
