package common;

import java.util.Map;

public interface Informant {

    boolean hasInformation();

    Map archive();
}
