package common;

public interface DownloadNotify {

    void complete(String string);

    void cancel();
}
