package common;

public interface Callback {
    void result(String string, Object object);
}
