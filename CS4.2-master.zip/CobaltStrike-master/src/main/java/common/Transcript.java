package common;

public interface Transcript {
}
