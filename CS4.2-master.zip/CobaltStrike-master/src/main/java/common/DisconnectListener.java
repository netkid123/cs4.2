package common;

public interface DisconnectListener {
    void disconnected(TeamSocket paramTeamSocket);
}
