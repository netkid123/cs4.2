package common;

public interface Do {
    boolean moment(String string);
}
