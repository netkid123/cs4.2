package common;

import sleep.runtime.Scalar;

public interface ToScalar {
    Scalar toScalar();
}
