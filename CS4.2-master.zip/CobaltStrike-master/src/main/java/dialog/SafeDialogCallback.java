package dialog;

public interface SafeDialogCallback {
    void dialogResult(String string);
}
