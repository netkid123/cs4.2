package graph;

import java.awt.event.MouseEvent;

public abstract interface GraphPopup
{
  public abstract void showGraphPopup(String[] arrstring, MouseEvent mouseEvent);
}
