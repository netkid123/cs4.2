package socks;

public interface ProxyListener {
    void proxyEvent(SocksProxy socksProxy, ProxyEvent paramProxyEvent);
}
