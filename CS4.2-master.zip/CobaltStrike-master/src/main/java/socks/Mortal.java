package socks;

import java.util.Map;

public interface Mortal {
    void die();

    int getPort();

    Map toMap();
}
