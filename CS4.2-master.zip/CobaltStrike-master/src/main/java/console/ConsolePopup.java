package console;

import java.awt.event.MouseEvent;

public interface ConsolePopup {
    void showPopup(String string, MouseEvent mouseEvent);
}
