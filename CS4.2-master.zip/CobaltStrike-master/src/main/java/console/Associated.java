package console;

public interface Associated {
    String getBeaconID();
}
