package console;

import javax.swing.JLabel;

public interface Activity {

    void registerLabel(JLabel l);

    void resetNotification();
}
