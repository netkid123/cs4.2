package filter;

public interface Criteria {
    boolean test(Object object);
}
