package importers;

public interface ImportHandler {
    void host(String string1, String string2, String string3, double d);

    void service(String string1, String string2, String string3);
}
