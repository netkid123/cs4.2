package server;

import c2profile.Profile;

public class ProfileEdits {
    public ProfileEdits(Profile profile) {
    }
}
