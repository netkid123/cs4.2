package cloudstrike;

public interface ResponseFilter {
    void filterResponse(Response response);
}
