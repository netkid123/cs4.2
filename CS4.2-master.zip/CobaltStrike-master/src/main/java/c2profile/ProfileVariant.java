package c2profile;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ProfileVariant implements Serializable {
    protected Map data = new HashMap();

    protected Map datal = new HashMap();
}
